<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Exito</title>
    <link rel="stylesheet" href="/css/styles.css">

</head>
<body>
    <h1>Album añadido!</h1>
    <a href="index.php">Añadir otro Album</a>
</body>
</html>
